// import {RequestUtil} from 'react'
// const requestUtil = new RequestUtil();
// export const getAllBookDetails = async (id:any) => {
    
//     try{
//             const response = await requestUtil._request.get(`api/illumina/allBook`,{Headers: { `Content-type`:'application/json'}})
//             return response.data;
//         } catch(error){
//             console.error('error fetching data',error)
//     }
// };